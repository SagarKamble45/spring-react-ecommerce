package com.sagark.ecommerce.project.util;

import com.sagark.ecommerce.project.model.User;
import com.sagark.ecommerce.project.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;


@Component
public class AuthUtil {
    @Autowired
    UserRepository userRepository;

    public String loggedInUsername(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User user = userRepository.findByUserName(authentication.getName()).orElseThrow(()-> new UsernameNotFoundException("User not found: "+ authentication.getName()));

        return user.getUserName();
    }

    public Long loggedInUserId(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User user = userRepository.findByUserName(authentication.getName()).orElseThrow(()-> new UsernameNotFoundException("User not found: "+authentication.getName() ));

        return user.getUserId();
    }

    public User loggedInUser(){
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User user = userRepository.findByUserName(authentication.getName()).orElseThrow(()-> new UsernameNotFoundException("User not found: " +authentication.getName() ));

        return user;
    }


    public String loggedInEmail() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        User user = userRepository.findByUserName(authentication.getName()).orElseThrow(()-> new UsernameNotFoundException("User not found: " +authentication.getName() ));

        return user.getEmail();
    }
}
