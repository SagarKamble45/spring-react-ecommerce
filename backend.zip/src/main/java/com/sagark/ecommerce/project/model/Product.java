package com.sagark.ecommerce.project.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.aot.generate.GeneratedTypeReference;
import org.springframework.resilience.annotation.EnableResilientMethods;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "products")
@ToString
public class Product {

    @Id
    @GeneratedValue(strategy =GenerationType.IDENTITY )
    private Long productId;

    @NotBlank
    @Size(min = 3, message = "Product name must contains atleast 3 characters")
    private String productName;
    private String image;

    @NotBlank
    @Size(min = 6, message = "Product name must contains atleast 6 characters")
    private String description;
    private Integer quantity;
    private  double price;
    private double discount;
    private double specialPrice;


    @ManyToOne
    @JoinColumn(name = "category_id")
    private Category category;

    @ManyToOne
    @JoinColumn(name = "seller_id")
    private User user;

    @OneToMany(mappedBy = "product", cascade = {CascadeType.PERSIST, CascadeType.MERGE},fetch=FetchType.EAGER)
//    private List<CartItem> products = new ArrayList<>();
    private List<CartItem> cartItems = new ArrayList<>();

}
