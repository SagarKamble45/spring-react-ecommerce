package com.sagark.ecommerce.project.service;

import com.sagark.ecommerce.project.exceptions.APIException;
import com.sagark.ecommerce.project.exceptions.ResourceNotFoundException;
import com.sagark.ecommerce.project.model.Cart;
import com.sagark.ecommerce.project.model.Category;
import com.sagark.ecommerce.project.model.Product;
import com.sagark.ecommerce.project.paylod.*;
import com.sagark.ecommerce.project.repositories.CartRepository;
import com.sagark.ecommerce.project.repositories.CategoryRepository;
import com.sagark.ecommerce.project.repositories.ProductRepository;

import com.sagark.ecommerce.project.util.ImageNameUtil;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private FileService fileService;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ImageNameUtil imageNameUtil;

    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private CartService cartService;

    @Value("${project.image}")
    private String path;


    @Override
    public ProductDTO addProduct(Long categoryId, ProductDTO productDTO) {


        Category category = categoryRepository.findById(categoryId).
                orElseThrow(()-> new ResourceNotFoundException("Category", "categoryId", categoryId));

        // check if the product is already present or not
        boolean ifProductNotPresent = true;
        List<Product> products = category.getProducts();
        for (Product value : products) {
            if (value.getProductName().equals(productDTO.getProductName())) {
                ifProductNotPresent = false;
                break;
            }
        }
        if (ifProductNotPresent){
            Product product = modelMapper.map(productDTO, Product.class);

            if (product.getImage() == null || product.getImage().isBlank()) {
                product.setImage("default.png");
            }

            product.setCategory(category);
            double specialPrice = product.getPrice() - ((product.getDiscount() * 0.01)*product.getPrice());
            product.setSpecialPrice(specialPrice);
            Product savedProduct = productRepository.save(product);

            return modelMapper.map(savedProduct, ProductDTO.class);
        }else {
            throw new APIException("Product already exists");
        }

    }

    @Override
    public ProductResponse getAllProducts(Integer pageNumber, Integer pageSize, String sortBy, String sortOrder, String keyword, String category) {

        Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();

        Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortByAndOrder);


//        Specification<Product> spec = Specification.where((Specification<Product>) null);


        Specification<Product> spec =(root, query, criteriaBuilder) -> criteriaBuilder.conjunction();
        if(keyword != null && !keyword.isEmpty()) {
            spec = spec.and((root, query, criteriaBuilder) -> criteriaBuilder.like(criteriaBuilder.lower(root.get("productName")), "%" + keyword.toLowerCase() + "%"));
        }

        if(category != null && !category.isEmpty()) {
            spec = spec.and((root, query, criteriaBuilder) -> criteriaBuilder.like(root.get("category").get("categoryName"), category));
        }

        Page<Product> pageProducts = productRepository.findAll(spec, pageDetails);
        // check if product size is 0 or not
    List<Product> products = pageProducts.getContent();
    List<ProductDTO> productDTOS = products.stream()
            .map(product -> {
                ProductDTO productDTO = modelMapper.map(product,ProductDTO.class);
                productDTO.setImage(imageNameUtil.constructImageUrl(product.getImage()));
                return productDTO;
            })
            .toList();

//    if (products.isEmpty()){
//        throw new APIException("No Products Exists");
//    }

    ProductResponse productResponse = new ProductResponse();
    productResponse.setContent(productDTOS);
    productResponse.setPageNumber(pageProducts.getNumber());
    productResponse.setPageSize(pageProducts.getSize());
    productResponse.setTotalElements(pageProducts.getTotalElements());
    productResponse.setTotalPages(pageProducts.getTotalPages());
    productResponse.setLastPage(pageProducts.isLast());
    return productResponse;
    }


    @Override
    public ProductResponse searchByCategory(Long categoryId, Integer pageNumber, Integer pageSize, String sortBy, String sortOrder) {

        Category category = categoryRepository.findById(categoryId).
                orElseThrow(()-> new ResourceNotFoundException("Category", "categoryId", categoryId));

        Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortByAndOrder);
        Page<Product> pageProducts = productRepository.findByCategoryOrderByPriceAsc(category, pageDetails);

        List<Product> products = pageProducts.getContent();

        if (products.isEmpty()){
            throw new APIException(category.getCategoryName() + " category does not have any products");
        }

        List<ProductDTO> productDTOS = products.stream().map(product -> modelMapper.map(product,ProductDTO.class)).toList();

        ProductResponse productResponse = new ProductResponse();
        productResponse.setContent(productDTOS);
        productResponse.setPageNumber(pageProducts.getNumber());
        productResponse.setPageSize(pageProducts.getSize());
        productResponse.setTotalElements(pageProducts.getTotalElements());
        productResponse.setTotalPages(pageProducts.getTotalPages());
        productResponse.setLastPage(pageProducts.isLast());
        return productResponse;
    }

    @Override
    public ProductResponse searchProductByKeyword( Integer pageNumber, Integer pageSize, String sortBy, String sortOrder, String keyword) {

        Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortByAndOrder);
        Page<Product> pageProducts = productRepository.findByProductNameLikeIgnoreCase('%' + keyword + '%', pageDetails);


        List<Product> products = pageProducts.getContent();
        List<ProductDTO> productDTOS = products.stream().map(product -> modelMapper.map(product,ProductDTO.class)).toList();
        if (products.isEmpty()){
            throw new APIException("Products not found with keyword: " + keyword);
        }

        ProductResponse productResponse = new ProductResponse();
        productResponse.setContent(productDTOS);
        productResponse.setPageNumber(pageProducts.getNumber());
        productResponse.setPageSize(pageProducts.getSize());
        productResponse.setTotalElements(pageProducts.getTotalElements());
        productResponse.setTotalPages(pageProducts.getTotalPages());
        productResponse.setLastPage(pageProducts.isLast());
        return productResponse;
    }

    @Override
    public ProductDTO updateProduct(Long productId, ProductDTO productDTO) {
        //GEt the existing product from DB
        Product productFromDb = productRepository.findById(productId).orElseThrow(
                () -> new ResourceNotFoundException("Product", "productId",productId));

        Product product = modelMapper.map(productDTO, Product.class);

        //update the product info with the one in request body
        productFromDb.setProductName(product.getProductName());
        productFromDb.setDescription(product.getDescription());
        productFromDb.setPrice(product.getPrice());
        productFromDb.setQuantity(product.getQuantity());
        productFromDb.setDiscount(product.getDiscount());
        productFromDb.setSpecialPrice(product.getSpecialPrice());

        //save to DB
        Product savedProduct = productRepository.save(productFromDb);

        List<Cart> carts = cartRepository.findCartsByProductId(productId);

        List<CartDTO> cartDTOs = carts.stream().map(cart -> {
            CartDTO cartDTO = modelMapper.map(cart, CartDTO.class);
            List<ProductDTO> products = cart.getCartItems().stream().map(p-> modelMapper.map(p.getProduct(), ProductDTO.class)).toList();
            cartDTO.setProducts(products);
            return cartDTO;
        }).toList();

        cartDTOs.forEach(cart -> cartService.updateProductInCarts(cart.getCartId(), productId));

        return modelMapper.map(savedProduct, ProductDTO.class);

    }

    @Override
    public ProductDTO deleteProduct(Long productId) {
        Product productFromDb = productRepository.findById(productId).orElseThrow(
                () -> new ResourceNotFoundException("Product", "productId",productId));

        List<Cart> carts = cartRepository.findCartsByProductId(productId);
        carts.forEach(cart -> cartService.deleteProductFromCart(cart.getCartId(), productId));

        productRepository.delete(productFromDb);
        return modelMapper.map(productFromDb, ProductDTO.class);
    }

    @Override
    public ProductDTO updateProductImage(Long productId, MultipartFile image) throws IOException {
        // Get the product from DB
        Product productFromDb = productRepository.findById(productId).orElseThrow(()-> new ResourceNotFoundException("Product", "productId", productId));

        // upload image to server
        // get the file name of the uploaded image
//        String path = "/images";
        String fileName = fileService.uploadImage(path, image);

        // updating the new file name to the product
        productFromDb.setImage(fileName);

        //save updated product
        Product updatedProduct = productRepository.save(productFromDb);
        //return DTO after mapping product to DTO
        return modelMapper.map(updatedProduct, ProductDTO.class);
    }


    @Override
    public ProductResponse getAllProductsforAdmin(String keyword, String category, String stockStatus, Integer pageNumber, Integer pageSize,
                                                  String sortBy, String sortOrder) {

        Sort sortByAndOrder = sortOrder.equalsIgnoreCase("asc")
                ? Sort.by(sortBy).ascending()
                : Sort.by(sortBy).descending();

        Pageable pageDetails = PageRequest.of(pageNumber, pageSize, sortByAndOrder);

        Specification<Product> spec = (root, query, cb) -> cb.conjunction();

        // Search box: product name, category name, or exact product ID
        if (keyword != null && !keyword.isBlank()) {
            String like = "%" + keyword.trim().toLowerCase() + "%";
            String trimmed = keyword.trim();

            spec = spec.and((root, query, cb) -> {
                var byName     = cb.like(cb.lower(root.get("productName")), like);
                var byCategory = cb.like(cb.lower(root.get("category").get("categoryName")), like);

                if (trimmed.matches("\\d+")) {                       // "13" also matches productId 13
                    return cb.or(byName, byCategory,
                            cb.equal(root.get("productId"), Long.parseLong(trimmed)));
                }
                return cb.or(byName, byCategory);
            });
        }

        // Category dropdown (exact name, case-insensitive)
        if (category != null && !category.isBlank()) {
            spec = spec.and((root, query, cb) ->
                    cb.equal(cb.lower(root.get("category").get("categoryName")),
                            category.trim().toLowerCase()));
        }

        // Status dropdown. The low-stock threshold (5) must match LOW_STOCK_THRESHOLD in the frontend.
        if (stockStatus != null && !stockStatus.isBlank()) {
            spec = spec.and((root, query, cb) -> switch (stockStatus.toUpperCase()) {
                case "OUT_OF_STOCK" -> cb.lessThanOrEqualTo(root.get("quantity"), 0);
                case "LOW_STOCK"    -> cb.between(root.get("quantity"), 1, 5);
                case "IN_STOCK"     -> cb.greaterThan(root.get("quantity"), 5);
                default             -> cb.conjunction();
            });
        }

        Page<Product> pageProducts = productRepository.findAll(spec, pageDetails);

        List<ProductDTO> productDTOS = pageProducts.getContent().stream()
                .map(product -> {
                    ProductDTO dto = modelMapper.map(product, ProductDTO.class);
                    dto.setCategoryName(product.getCategory().getCategoryName());
                    dto.setImage(imageNameUtil.constructImageUrl(product.getImage()));
                    return dto;
                })
                .toList();

        ProductResponse response = new ProductResponse();
        response.setContent(productDTOS);
        response.setPageNumber(pageProducts.getNumber());
        response.setPageSize(pageProducts.getSize());
        response.setTotalElements(pageProducts.getTotalElements());
        response.setTotalPages(pageProducts.getTotalPages());
        response.setLastPage(pageProducts.isLast());
        return response;
    }


    @Override
    public ProductStatsDTO getProductStats() {
        ProductStatsDTO productStatsDTO = new ProductStatsDTO();

        long totalProducts = productRepository.findAll().size();
        long activeProducts = productRepository.getTotalActiveProducts();
        long totalOutofStockProducts = productRepository.getTotalOutOfStockProducts();
        long totalCategories = categoryRepository.findAll().size();

        productStatsDTO.setTotalProducts(String.valueOf(totalProducts));
        productStatsDTO.setTotalActiveProducts(String.valueOf(activeProducts));
        productStatsDTO.setTotalOutOfStockProducts(String.valueOf(totalOutofStockProducts));
        productStatsDTO.setTotalCategories(String.valueOf(totalCategories));

        return productStatsDTO;
    }

    @Override
    public List<RecentProductDTO> getLatestFiveOrders() {
        List<Product> products = productRepository.findLatestFiveProducts();

        List<RecentProductDTO> recentProductDTOS = products.stream().map(product -> {
            RecentProductDTO recentProductDTO = modelMapper.map(product, RecentProductDTO.class);
            recentProductDTO.setImage(imageNameUtil.constructImageUrl(product.getImage()));
            return recentProductDTO;
        }).toList();
        return  recentProductDTOS;
    }


}
